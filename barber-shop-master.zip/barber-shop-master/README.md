# barber-shop
Software that allows customers to schedule appointments remotely. Using ReacJS and Laravel Php
