export const FETCH_CATEGORY = 'FETCH_CATEGORY';
export const FETCH_TAG = 'FETCH_TAG';

export const FETCH_BLOGS = 'FETCH_BLOGS';
export const FETCH_BLOGS_BY_ID = 'FETCH_BLOGS_BY_ID';