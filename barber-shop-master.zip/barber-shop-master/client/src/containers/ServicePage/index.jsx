import React from 'react';

const ServicePage = () => {
  return <div></div>;
};

export default ServicePage;
