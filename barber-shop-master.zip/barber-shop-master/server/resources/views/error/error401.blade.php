<!DOCTYPE html>
<html>
    <head>
        <meta charset="utf-8">
        <title>Error 400</title>
        <link rel="stylesheet" type="text/css" href="{{ URL::to('css/error.css') }}">
    </head>
    <body>
        <div class="container">
            <div class="body-err">
                <p class="text-err">Error 400 Bad Request Error</p>
            </div>
        </div>
    </body>
</html>