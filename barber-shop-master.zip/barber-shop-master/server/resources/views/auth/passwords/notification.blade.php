@extends('layouts.layout-login')

@section('account_content')
<div class="login-form">
    <h3 class="login-head"><i class="fa fa-lg fa-fw fa-lock"></i>Quên mật khẩu ?</h3>
    <div class="form-group">
    <h4>Kiểm tra Email của bạn</h4>
    <p style="font-size:15px; word-spacing:2px">Chúng tôi vừa gửi email cho bạn với một liên kết để đặt lại mật khẩu của bạn!</p>
    </div>
</div>
@endsection